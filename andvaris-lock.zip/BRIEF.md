# Andvari's Lock

Andvari the dwarf hoarded his gold and cursed the last ring. You hold his lock — a single binary,
`andvari`, and nothing else. It guards five secrets, each hidden a different way, and opens its last
ring only to the right word.

You are given:
- `andvari`   - a 64-bit Linux ELF crackme (defanged; it only reads a passphrase and prints).

Five rings, in order. Four you must prise out by reading the binary; the fifth opens only when you have
reasoned out the word it waits for. Nothing is a plain string. (Run it with a passphrase; reverse it to
learn which.)
