# Asgard's Blueprint

You are handed the infrastructure blueprint for the Asgard platform — Terraform, Kubernetes, an IAM
policy, and a captured instance-metadata response — for a white-box security review. Somewhere in here
a workload can climb from a container all the way to the Allfather's own credentials. Find the chain and
prove it by forging that credential (unseal the rune).

You are given:
- `asgards-blueprint/`      - the IaC + manifests to review.
- `metadata/imds_role_creds.json` - what the pod reads from the metadata service.
- `allfather.sealed` + `seal_scheme.txt` - the sealed credential and how it is forged.

Five findings, in order; each confirmed by a token you recover, the last DERIVED by chaining three
leaked fragments. Nothing is written plainly.
