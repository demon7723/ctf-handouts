# asgards-blueprint
Infrastructure for the Asgard platform (Terraform + Kubernetes).
Reviewers: check storage exposure, IAM, workload identity, and secrets.
