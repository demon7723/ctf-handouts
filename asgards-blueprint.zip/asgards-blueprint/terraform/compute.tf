resource "aws_instance" "gladsheim" {
  ami           = "ami-asgard-01"
  instance_type = "m6i.large"
  iam_instance_profile = "einherjar-runner"
  metadata_options {
    http_endpoint = "enabled"
    http_tokens   = "optional"   # <-- IMDSv1 allowed (no session token required)
    http_put_response_hop_limit = 3   # <-- containers can reach the metadata service
  }
}
