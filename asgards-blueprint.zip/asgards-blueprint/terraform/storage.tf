resource "aws_s3_bucket" "mimir_well" {
  bucket = "asgard-mimir-well"
}
resource "aws_s3_bucket_acl" "mimir_well" {
  bucket = aws_s3_bucket.mimir_well.id
  acl    = "public-read"     # <-- world-readable bucket
}
resource "aws_s3_object" "runbook" {
  bucket = aws_s3_bucket.mimir_well.id
  key    = "ops/runbook.txt"
  tags   = { audit = "TkV7dGhlX3dlbGxfb2ZfbWltaXJfd2FzX2xlZnRfcHVibGljfQ==" }   # a token left in an object tag, in a PUBLIC bucket
}
