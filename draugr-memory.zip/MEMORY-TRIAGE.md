# Draugr in the Memory

A host was raised from the dead and made to walk — a draugr in its memory. You hold a triage bundle
pulled from the machine. Walk the whole haunting: the dead name in the process list, the words still
buried in memory, the sample that unwinds its own shroud, the grave-goods hidden in a cache, and the
draugr's master named at last.

You are given:
- `pslist.json`      - the process list at capture.
- `memdump.strings`  - strings carved from physical memory (regions tagged).
- `sample_7f3a.js`   - a recovered dropper fragment (defanged; does not run).
- `wmicache.dat`     - a staged payload referenced by persistence.
- `hive_run.txt`     - registry Run-key excerpt.
- `final.sealed` + `seal_scheme.txt` - the sealed final word and how it is forged.

Five findings, in order; each step's key unlocks the next, and the last is derived. Nothing is plain.
