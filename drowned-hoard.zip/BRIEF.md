# The Drowned Hoard

A longship went down with the hoard aboard. The salvage crew raised one fragment of the seabed —
`drowned_hoard.dd`. The sea layered the treasure: a thing carved inside a thing inside a thing.

You are given:
- `drowned_hoard.dd`   — the raw salvaged fragment. Carve what the sea embedded; mind the decoys.
- `catalog.json`       — the quartermaster's index of recovered artifacts and their recorded ages.
- `drowned_longship.sealed` — the sealed rune. It rises only for the one who knows the hoard's true age.
- `seal_scheme.txt`    — how the seal is forged (not what opens it).

Five seals, in order. Nothing is written plainly; each is carved, decoded, correlated, or derived.
The quartermaster's ledger lies about one age — trust the driftwood's own rings.
