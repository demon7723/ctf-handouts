# Heimdall's Watch — Incident Bundle

Heimdall keeps the Gjallarhorn and the watch over the Bifrost. Last night the horn did not sound — yet
by morning something had crossed. You are handed a day of the realm's watch-logs. Walk the whole crossing,
from the first footfall to the name of the one who truly crossed.

You are given:
- `security.jsonl`      — logon telemetry across the realm's halls (event 4624/4625).
- `edr_process.jsonl`   — process-creation telemetry from the endpoints.
- `scheduled_tasks.jsonl` — scheduled-task inventory.
- `dns.csv`, `proxy.csv` — name resolution and egress-proxy records.
- `firewall_nat.csv`    — the border watch: inbound/outbound sessions and their address translations.
- `final.sealed`        — a sealed rune. It opens only to the one who can name the true crosser.

Five seals, in order. Each is earned — none is written plainly. The watchman saw more than the hall's
own ledger admits; trust the border over the hall.
