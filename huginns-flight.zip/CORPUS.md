# Huginn's Flight

Huginn the raven flies over all the Nine Realms and brings Odin what he sees. You hold one flight's worth
of what the raven gathered about Asgard — a slice of the open world, entirely self-contained (no live
sites). Correlate what leaks across it to fly straight to the hall Asgard tried to hide.

You are given (`huginn-corpus/`):
- `certs.json`   - certificate-transparency entries for asgard.example.
- `git_mirror/`  - a public code mirror: a log and removed blobs preserved in history.
- `docs/`        - a press release and its document metadata.
- `pastes.json`  - a dump of public pastes.
- `social.json`  - public social posts (mostly noise).
Plus `hidden_asset.sealed` + `seal_scheme.txt`.

Five findings, in order; each confirmed by a token you recover, the last DERIVED by correlating three
facts from three different sources. Nothing is written plainly.
