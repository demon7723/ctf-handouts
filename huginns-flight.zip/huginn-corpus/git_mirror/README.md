einherjar service (public mirror). See git_log.txt; history/ holds removed blobs.
