# The Norns' Cipher

Urd, Verdandi, and Skuld weave the fate of all things — and each wove carelessly. Four threads, four
flaws; break each offline and the last is derived.

Files:
- `thread.bin`       - a message under a repeating key; every message begins with the ward in URD's tongue.
- `weft_public.bin` + `weft_public.txt`, `weft_secret.bin` - two wefts woven on the SAME keystream (one's words are public).
- `fate_keys.json`   - two Norn RSA keys; one shares a prime with fate.
- `small_exponent.json` - an RSA message under a very small public exponent, unpadded.
- `wyrd.sealed` + `seal_scheme.txt` - the sealed final word.

Five threads, in order; nothing is a plain string; the last is derived.
