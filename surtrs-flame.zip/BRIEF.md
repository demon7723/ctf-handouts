# Surtr's Flame

Surtr stands at the edge of Muspelheim with a flaming sword, and five times he guards the fire. You hold
his binary, `surtr`, and nothing else. Each trial (run `./surtr <1-5>`) guards a flame behind a different
flaw in how it handles what you give it. Reach each flame your own way.

Five trials, five primitives. Nothing is a plain string; each flame is lit only when the exploit lands.
(64-bit Linux ELF, no PIE, no stack canary. Bring your debugger and your gadgets.)
