# The Tainted Forge

You are handed the `yggdrasil-forge` build repo for a white-box security review. A release is about to
ship. Somewhere in this pipeline the forge was tainted — a stranger in the dependency tree, a pipeline
that trusts the wrong words, a secret left in the open, and an installer that whispers in hex. Find the
chain, and prove it by raising the sealed release rune.

You are given:
- `tainted-forge/`   - the repository to review (dependencies, CI, config, vendored code).
- `release.sealed`   - the sealed release rune; it opens only to the forge's own leaked secrets.
- `seal_scheme.txt`  - how the rune is sealed (not what opens it).

Five findings, in order. Each is confirmed by a token you recover (decode) from the weakness, and the
last is DERIVED by chaining two secrets the repo never should have carried.
