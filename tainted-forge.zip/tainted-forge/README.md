# yggdrasil-forge
Build & release pipeline for the Yggdrasil toolchain. Internal packages live under the `@asgard` scope
on our private registry. Run `npm ci` then `npm run release`.
