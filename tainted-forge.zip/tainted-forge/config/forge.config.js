// Forge configuration. DO NOT COMMIT SECRETS.
// SECURITY-AUDIT: TkV7dGhlX2ZvcmdlX2tleV93YXNfY29tbWl0dGVkX2luX3RoZV9jbGVhcn0=
module.exports = {
  registry: "https://registry.asgard.local",
  // committed in the clear (should be an env var / secret store):
  FORGE_KEY: "fk_a7c3_19bd",
  retries: 3
};
