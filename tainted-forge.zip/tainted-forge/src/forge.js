const cfg = require("../config/forge.config.js");
// Signs the release tarball with the forge key + the vendored util's signer.
const sign = require("../vendor/yggdrasil-utils");
module.exports = function release(tarball) { return sign(tarball, cfg.FORGE_KEY); };
