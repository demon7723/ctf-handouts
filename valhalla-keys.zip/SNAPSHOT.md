# Keys to Valhalla

A white-box snapshot of a domain-joined host and a slice of its SYSVOL. Review it: a humble service
account can climb to root on the box and, through what the domain left lying in its policies, to the
keys of Valhalla itself. Find the chain and derive the final key.

You are given:
- `valhalla-snapshot/` - sudo rights, cron, file perms, shell history, a SYSVOL GPP policy, a secrets dump.
- `valhalla.sealed` + `seal_scheme.txt` - the sealed domain keys and how they are forged.

Five findings, in order; each confirmed by a token you recover, the last DERIVED from two recovered
credentials. Nothing is written plainly.
