# Whispers in the Mist

A full day of the realm's traffic crossed the mist, and under the noise one host stole a scroll and
carried it out by more than one hidden road. You hold the capture. Find the whisperer, follow every
road it used, and lift the fog on the whole theft.

You are given:
- `whispers.pcap`   - the packet capture (benign traffic plus one host's covert exfil).
- `seal_scheme.txt` - how the stolen scroll is sealed (not what opens it).

Five findings, in order: the whisperer, the names in the mist, the rebuilt scroll, the key the pings
carried, and the lifting of the fog. Nothing is written plainly; the last is derived.
